# Movie Recommendation Fullstack App

## Overview

A full-featured movie recommendation platform built with React, Express, and MongoDB.

## Features

- User authentication with JWT
- Search movies via TMDB API
- Save favorites, watchlists, and rate movies
- Responsive UI (mobile & desktop)

## Tech Stack

- **Frontend**: React, Tailwind CSS (to be implemented)
- **Backend**: Express.js, MongoDB, JWT
- **Database**: MongoDB
- **External API**: TMDB

## Setup

### Backend

1. Navigate to `backend/`
2. Create `.env` file from `.env.example`
3. Run:

```bash
npm install
npm start
```

### Frontend

1. Navigate to `frontend/`
2. Set up your React app:

```bash
npx create-react-app .
npm start
```

## Deployment

- **Frontend**: Vercel / Netlify
- **Backend**: Render / Railway / Heroku

## Coming Soon

- Social features
- PWA support
- Movie trailer integration
