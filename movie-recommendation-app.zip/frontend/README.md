# React Frontend (Placeholder)

This folder is intended for the React frontend of the Movie Recommendation App.
